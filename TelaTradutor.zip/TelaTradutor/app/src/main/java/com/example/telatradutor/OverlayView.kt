package com.example.telatradutor

import android.content.Context
import android.graphics.*
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

data class Item(val rect: Rect, val text: String, val size: Float)

class OverlayView(context: Context) : View(context) {
    var items: List<Item> = emptyList()
        set(value) { field = value; invalidate() }

    private val bg = Paint().apply { color = 0xF2141414.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        for (i in items) {
            tp.textSize = i.size
            val w = i.rect.width().coerceAtLeast(120)
            val layout = StaticLayout.Builder.obtain(i.text, 0, i.text.length, tp, w).build()
            val h = maxOf(i.rect.height(), layout.height)
            canvas.drawRect(
                i.rect.left.toFloat(), i.rect.top.toFloat(),
                (i.rect.left + w).toFloat(), (i.rect.top + h).toFloat(), bg
            )
            canvas.save()
            canvas.translate(i.rect.left.toFloat(), i.rect.top.toFloat())
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
