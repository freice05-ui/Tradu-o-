package com.example.telatradutor

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

class TranslateService : Service() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var wm: WindowManager
    private lateinit var bubble: TextView
    private lateinit var overlay: OverlayView
    private var projection: MediaProjection? = null
    private var vDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var w = 0
    private var h = 0
    private var busy = false
    private var showing = false

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.PORTUGUESE)
            .build()
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null || intent == null) return START_NOT_STICKY

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("t", "Tradutor", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, "t")
            .setContentTitle("Tradutor de tela ativo")
            .setContentText("Toque na bolha para traduzir. Segure para sair.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java) ?: return START_NOT_STICKY
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, null)
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        w = b.width(); h = b.height()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vDisplay = projection!!.createVirtualDisplay(
            "cap", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )

        addOverlay()
        addBubble()

        scope.launch {
            try {
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                toast("Pronto! Toque na bolha 🌐")
            } catch (e: Exception) {
                toast("Falha ao baixar o modelo de tradução. Conecte-se à internet.")
            }
        }
        return START_NOT_STICKY
    }

    private fun overlayParams(matchParent: Boolean) = WindowManager.LayoutParams(
        if (matchParent) WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,
        if (matchParent) WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (matchParent) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0),
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    }

    private fun addOverlay() {
        overlay = OverlayView(this)
        wm.addView(overlay, overlayParams(true))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        bubble = TextView(this).apply {
            text = "🌐"; textSize = 24f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC3367D6.toInt()) }
            width = 150; height = 150
        }
        val lp = overlayParams(false).apply { x = 20; y = 400 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var t0 = 0L
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; t0 = System.currentTimeMillis() }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(bubble, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (System.currentTimeMillis() - t0 > 600) stopSelf() else toggle()
                }
            }
            true
        }
        wm.addView(bubble, lp)
    }

    private fun toggle() {
        if (showing) { overlay.items = emptyList(); showing = false } else translateScreen()
    }

    private fun translateScreen() {
        if (busy) return
        busy = true
        scope.launch {
            try {
                bubble.visibility = View.INVISIBLE
                overlay.visibility = View.INVISIBLE
                delay(250) // espera um quadro novo sem a bolha
                val bmp = grab()
                bubble.visibility = View.VISIBLE
                overlay.visibility = View.VISIBLE
                if (bmp == null) { toast("Não consegui capturar a tela."); return@launch }

                val text = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
                val blocks = text.textBlocks.mapNotNull { blk ->
                    val box = blk.boundingBox ?: return@mapNotNull null
                    val src = blk.text.replace("\n", " ").trim()
                    if (src.count { it.isLetter() } < 2) return@mapNotNull null
                    val size = (box.height() / blk.lines.size.coerceAtLeast(1) * 0.7f).coerceIn(22f, 80f)
                    Triple(box, src, size)
                }
                val tr = if (blocks.isEmpty()) emptyList() else translateAll(blocks.map { it.second })
                val items = blocks.mapIndexed { i, b -> Item(b.first, tr[i], b.third) }
                overlay.items = items
                showing = items.isNotEmpty()
                if (items.isEmpty()) toast("Nenhum texto encontrado.")
            } catch (e: Exception) {
                toast("Erro: ${e.message}")
            } finally {
                bubble.visibility = View.VISIBLE
                overlay.visibility = View.VISIBLE
                busy = false
            }
        }
    }

    // Com chave da API: Claude traduz todos os trechos juntos, entendendo o contexto da tela.
    // Sem chave (ou se falhar): tradução local, trecho por trecho.
    private suspend fun translateAll(src: List<String>): List<String> {
        val key = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isNotBlank()) {
            try {
                return withContext(Dispatchers.IO) { if (key.startsWith("AIza")) gemini(key, src) else claude(key, src) }
            } catch (e: Exception) {
                toast("IA falhou (${e.message?.take(150)}). Usando tradução local.")
            }
        }
        return coroutineScope { src.map { async { translator.translate(it).await() } }.awaitAll() }
    }

    private fun buildPrompt(src: List<String>): String {
        val arr = JSONArray(); src.forEach { arr.put(it) }
        return "Traduza do inglês para o português do Brasil. Os textos abaixo são trechos de UMA mesma tela, " +
            "em ordem; use o contexto da tela inteira para escolher o sentido certo. Mantenha marcas, números e " +
            "botões curtos. Responda APENAS com um array JSON de strings, com exatamente ${src.size} itens, na mesma ordem.\n\n" +
            arr.toString()
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val resp = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception("HTTP ${c.responseCode}: $resp")
        return resp
    }

    private fun parseList(raw: String, n: Int): List<String> {
        val out = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val r = JSONArray(out)
        if (r.length() != n) throw Exception("tamanho diferente")
        return List(n) { r.getString(it) }
    }

    private fun claude(key: String, src: List<String>): List<String> {
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 4000)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", buildPrompt(src))))
        val resp = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body
        )
        return parseList(JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text"), src.size)
    }

    private fun gemini(key: String, src: List<String>): List<String> {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", buildPrompt(src))))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val resp = post(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-lite-latest:generateContent",
            mapOf("x-goog-api-key" to key), body
        )
        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return parseList(sb.toString(), src.size)
    }

    private suspend fun grab(): Bitmap? {
        repeat(15) {
            val img = reader?.acquireLatestImage()
            if (img != null) {
                val p = img.planes[0]
                val rowW = p.rowStride / p.pixelStride
                val full = Bitmap.createBitmap(rowW, img.height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(p.buffer)
                img.close()
                return Bitmap.createBitmap(full, 0, 0, w, h)
            }
            delay(100)
        }
        return null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        scope.cancel()
        runCatching { wm.removeView(bubble) }
        runCatching { wm.removeView(overlay) }
        vDisplay?.release(); reader?.close(); projection?.stop()
        recognizer.close(); translator.close()
        super.onDestroy()
    }
}
