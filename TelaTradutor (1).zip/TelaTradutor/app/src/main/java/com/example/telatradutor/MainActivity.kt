package com.example.telatradutor

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val info = TextView(this).apply {
            text = "Tradutor de tela (inglês → português)\n\n" +
                "1. Toque em Iniciar e conceda as permissões.\n" +
                "2. Abra qualquer app.\n" +
                "3. Toque na bolha 🌐 para traduzir a tela; toque de novo para limpar.\n" +
                "4. Segure a bolha para encerrar."
            textSize = 16f
        }
        val keyField = EditText(this).apply {
            hint = "Chave de API (Gemini grátis ou Anthropic) — opcional"
            setSingleLine()
            setText(getSharedPreferences("cfg", MODE_PRIVATE).getString("key", ""))
        }
        val btn = Button(this).apply {
            text = "Iniciar"
            setOnClickListener {
                getSharedPreferences("cfg", MODE_PRIVATE).edit()
                    .putString("key", keyField.text.toString().trim()).apply()
                start()
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(info)
            addView(keyField)
            addView(btn)
        })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita \"Exibir sobre outros apps\" e volte.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, TranslateService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
            )
            moveTaskToBack(true)
        }
    }
}
